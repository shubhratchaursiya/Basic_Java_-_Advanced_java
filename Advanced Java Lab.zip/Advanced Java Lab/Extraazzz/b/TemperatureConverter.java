/*2nd A Simple Converter Between Celsius and Fahrenhcit Using Swing Components. */
package b;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TemperatureConverter extends JFrame implements ActionListener {

    private JTextField txtCelsius, txtFahrenheit;
    private JButton btnCtoF, btnFtoC, btnClear;

    public TemperatureConverter() {
    	setTitle("Temperature Converter");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 200);
        setLayout(null);
        getContentPane().setBackground(Color.GREEN);
        
        JLabel heading = new JLabel("Temperature Converter By SHUBHRAT CHAURSIYA : 23EARIT053");
        heading.setBounds(10, 10, 500, 20);
        heading.setFont(new Font("Serif", Font.BOLD, 14));
        heading.setForeground(Color.BLUE);
        add(heading);


        // Celsius Label & Field
        JLabel lblCelsius = new JLabel("Celsius:");
        lblCelsius.setForeground(Color.WHITE);
        lblCelsius.setBounds(30, 30, 80, 25);
        add(lblCelsius);

        txtCelsius = new JTextField();
        txtCelsius.setBounds(110, 30, 100, 25);
        add(txtCelsius);

        // Fahrenheit Label & Field
        JLabel lblFahrenheit = new JLabel("Fahrenheit:");
        lblFahrenheit.setForeground(Color.WHITE);
        lblFahrenheit.setBounds(30, 70, 80, 25);
        add(lblFahrenheit);

        txtFahrenheit = new JTextField();
        txtFahrenheit.setBounds(110, 70, 100, 25);
        add(txtFahrenheit);

        // Buttons
        btnCtoF = new JButton("C → F");
        btnCtoF.setBounds(230, 30, 80, 25);
        btnCtoF.addActionListener(this);
        add(btnCtoF);

        btnFtoC = new JButton("F → C");
        btnFtoC.setBounds(230, 70, 80, 25);
        btnFtoC.addActionListener(this);
        add(btnFtoC);

        btnClear = new JButton("Clear");
        btnClear.setBounds(150, 110, 80, 25);
        btnClear.addActionListener(this);
        add(btnClear);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == btnCtoF) {
                double celsius = Double.parseDouble(txtCelsius.getText());
                double fahrenheit = (celsius * 9 / 5) + 32;
                txtFahrenheit.setText(String.format("%.2f", fahrenheit));
            } 
            else if (e.getSource() == btnFtoC) {
                double fahrenheit = Double.parseDouble(txtFahrenheit.getText());
                double celsius = (fahrenheit - 32) * 5 / 9;
                txtCelsius.setText(String.format("%.2f", celsius));
            } 
            else if (e.getSource() == btnClear) {
                txtCelsius.setText("");
                txtFahrenheit.setText("");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TemperatureConverter converter = new TemperatureConverter();
            converter.setVisible(true);
            converter.setLocationRelativeTo(null);
        });
    }
}