package b;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class UserOptionSelectionPage extends JFrame implements ActionListener {
	
    JCheckBox cbReading, cbTraveling, cbGaming;
    
    JRadioButton rbMale, rbFemale, rbOther;
    
    JComboBox<String> countryList;
    
    JButton btnSubmit;
    ButtonGroup bgGender;
    
    

    public UserOptionSelectionPage() {
        setTitle("Selection Page by SHUBHRAT CHAURSIYA 23EARIT053");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 300);
        setLayout(null);
        getContentPane().setBackground(Color.RED);



        JLabel lblHobbies = new JLabel("Hobbies:");
        lblHobbies.setForeground(Color.WHITE);
        lblHobbies.setBounds(30, 30, 70, 25);
        add(lblHobbies);

        cbReading = new JCheckBox("Reading");
        cbReading.setBackground(Color.RED);
        cbReading.setForeground(Color.WHITE);
        cbReading.setBounds(110, 30, 80, 25);
        add(cbReading);

        
        cbTraveling = new JCheckBox("Traveling");
        cbTraveling.setBackground(Color.RED);
        cbTraveling.setForeground(Color.WHITE);
        cbTraveling.setBounds(190, 30, 90, 25);
        add(cbTraveling);

        
        cbGaming = new JCheckBox("Gaming");
        cbGaming.setBackground(Color.RED);
        cbGaming.setForeground(Color.WHITE);
        cbGaming.setBounds(295, 30, 80, 25);
        add(cbGaming);

        
        JLabel lblGender = new JLabel("Gender:");
        lblGender.setForeground(Color.WHITE);
        lblGender.setBounds(30, 70, 70, 25);
        add(lblGender);

        rbMale = new JRadioButton("Male");
        rbMale.setBackground(Color.RED);
        rbMale.setForeground(Color.WHITE);
        rbMale.setBounds(110, 70, 60, 25);
        rbFemale = new JRadioButton("Female");
        rbFemale.setBackground(Color.RED);
        rbFemale.setForeground(Color.WHITE);
        rbFemale.setBounds(190, 70, 70, 25);
        rbOther = new JRadioButton("Other");
        rbOther.setBackground(Color.RED);
        rbOther.setForeground(Color.WHITE);
        rbOther.setBounds(270, 70, 70, 25);

        bgGender = new ButtonGroup();
        bgGender.add(rbMale);
        bgGender.add(rbFemale);
        bgGender.add(rbOther);

        add(rbMale);
        add(rbFemale);
        add(rbOther);

        JLabel lblCountry = new JLabel("Country:");
        lblCountry.setForeground(Color.WHITE);
        lblCountry.setBounds(30, 110, 70, 25);
        add(lblCountry);

        String[] countries = {"India", "USA", "China", "Australia", "Canada"};
        countryList = new JComboBox<>(countries);
        countryList.setBounds(110, 110, 250, 25);
        add(countryList);

        btnSubmit = new JButton("Submit");
        btnSubmit.setBounds(160, 150, 100, 30);
        btnSubmit.addActionListener(this);
        add(btnSubmit);
    }

    public void actionPerformed(ActionEvent e) {
        String hobbies = "";
        if (cbReading.isSelected()) hobbies += "Reading ";
        if (cbTraveling.isSelected()) hobbies += "Traveling ";
        if (cbGaming.isSelected()) hobbies += "Gaming ";
        hobbies = hobbies.trim();
        if (hobbies.isEmpty()) hobbies = "None";

        String gender = "";
        if (rbMale.isSelected()) gender = "Male";
        else if (rbFemale.isSelected()) gender = "Female";
        else if (rbOther.isSelected()) gender = "Other";
        else gender = "Not selected";

        String country = (String) countryList.getSelectedItem();

        String message = "Hobbies: " + hobbies + 
                        "\nGender: " + gender + 
                        "\nCountry: " + country;

        JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            UserOptionSelectionPage form = new UserOptionSelectionPage();
            form.setVisible(true);
            form.setLocationRelativeTo(null);
        });
    }
}