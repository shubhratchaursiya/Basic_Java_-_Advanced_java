package h;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Locale;
import java.util.ResourceBundle;
public class MultilingualMessage extends JFrame {

    private JTextArea textArea;
    private JButton btnShow;
    private JComboBox<String> languageSelector;

    public MultilingualMessage() {
        setTitle("Welcome Message App");
        setSize(550, 350);
        setLayout(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.GREEN);

        JLabel title = new JLabel("Welcome Message By SHUBHRAT CHAURSIYA - 23EARIT053", JLabel.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Color.RED);
        title.setBounds(20, 10, 500, 30);
        add(title);

        textArea = new JTextArea("Click the button to see Welcome Message");
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setEditable(false);
        
        textArea.setFont(new Font("Nirmala UI", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(textArea,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBounds(20, 60, 500, 150);
        add(scrollPane);

        String[] languages = {"English", "Hindi", "French", "Spanish"};
        languageSelector = new JComboBox<>(languages);
        languageSelector.setBounds(20, 240, 120, 30);
        add(languageSelector);

        btnShow = new JButton("Show Welcome");
        btnShow.setBounds(180, 240, 150, 30);
        add(btnShow);

        btnShow.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showMessage();
            }
        });
    }

    private void showMessage() {
        String choice = (String) languageSelector.getSelectedItem();
        Locale locale;

        switch (choice) {
            case "Hindi": locale = new Locale("hi", "IN"); break;
            case "French": locale = new Locale("fr", "FR"); break;
            case "Spanish": locale = new Locale("es", "ES"); break;
            default: locale = new Locale("en", "US"); break;
        }

        ResourceBundle messages = ResourceBundle.getBundle("h.Messages", locale);

        textArea.setText(messages.getString("welcome"));

        textArea.setText(messages.getString("welcome"));
        textArea.setCaretPosition(0);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MultilingualMessage().setVisible(true);
            }
        });
    }
}