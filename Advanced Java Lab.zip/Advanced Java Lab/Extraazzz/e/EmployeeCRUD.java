package e;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class EmployeeCRUD extends JFrame {
private static final long serialVersionUID = 1L;
    private JTextField txtId, txtName, txtSalary, txtSearch;
    private JButton btnSave, btnDelete, btnLoad, btnSearch, btnUpdate;
    private DefaultTableModel tableModel;
    private JTable employeeTable;
    private Connection conn;

    public EmployeeCRUD() {
        setTitle("Employee Data Entry System");
        setSize(750, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JLabel bigTitle = new JLabel("Employee Registration By ANTU KUMAR 23EARIT011", JLabel.CENTER);
        bigTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        bigTitle.setForeground(Color.black);
        add(bigTitle, BorderLayout.NORTH);

        JPanel leftPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblId = new JLabel("Employee ID:");
        JLabel lblName = new JLabel("Employee Name:");
        JLabel lblSalary = new JLabel("Salary:");
        JLabel lblSearch = new JLabel("Search (ID or Name):");

        txtId = new JTextField(12);
        txtName = new JTextField(12);
        txtSalary = new JTextField(12);
        txtSearch = new JTextField(12);

        btnSave = new JButton("Save");
        btnDelete = new JButton("Delete");
        btnLoad = new JButton("Load All");
        btnSearch = new JButton("Search");
        btnUpdate = new JButton("Update");

        gbc.gridx = 0; gbc.gridy = 0;
        leftPanel.add(lblId, gbc);
        gbc.gridx = 1;
        leftPanel.add(txtId, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        leftPanel.add(lblName, gbc);
        gbc.gridx = 1;
        leftPanel.add(txtName, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        leftPanel.add(lblSalary, gbc);
        gbc.gridx = 1;
        leftPanel.add(txtSalary, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        leftPanel.add(lblSearch, gbc);
        gbc.gridx = 1;
        leftPanel.add(txtSearch, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnSave);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnSearch);
        buttonPanel.add(btnLoad);

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        leftPanel.add(buttonPanel, gbc);

        add(leftPanel, BorderLayout.WEST);

        String[] columnNames = {"S.No", "Employee ID", "Employee Name", "Salary"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        employeeTable = new JTable(tableModel);
        employeeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(employeeTable);
        scrollPane.setPreferredSize(new Dimension(450, 350));
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.add(scrollPane, BorderLayout.CENTER);
        add(rightPanel, BorderLayout.CENTER);

        connectDatabase();

        btnSave.addActionListener(e -> saveEmployee());
        btnUpdate.addActionListener(e -> updateEmployee());
        btnDelete.addActionListener(e -> deleteEmployee());
        btnLoad.addActionListener(e -> loadEmployees());
        btnSearch.addActionListener(e -> searchEmployee());

        employeeTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && employeeTable.getSelectedRow() != -1) {
                int selectedRow = employeeTable.getSelectedRow();
                txtId.setText((String) tableModel.getValueAt(selectedRow, 1));
                txtName.setText((String) tableModel.getValueAt(selectedRow, 2));
                txtSalary.setText((String) tableModel.getValueAt(selectedRow, 3));
            }
        });

       
    }

    private void connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/connectDatabase?useSSL=false&serverTimezone=UTC";
            String username = "root";
            String password ="Pur23nima@1";

            conn = DriverManager.getConnection(url, username, password);
            Statement stmt = conn.createStatement();

            stmt.execute("CREATE TABLE IF NOT EXISTS employees (emp_id VARCHAR(50) PRIMARY KEY, emp_name VARCHAR(100), salary VARCHAR(100))");
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to database: " + e.getMessage());
            System.exit(1);
        }
    }

    private void saveEmployee() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String salary = txtSalary.getText().trim();

        if (id.isEmpty() || name.isEmpty() || salary.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }

        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO employees (emp_id, emp_name, salary) VALUES (?, ?, ?)");
            ps.setString(1, id);
            ps.setString(2, name);
            ps.setString(3, salary);
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(this, "Employee saved.");
            clearFields();
            loadEmployees();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saving employee. Maybe duplicate ID?");
        }
    }

    private void updateEmployee() {
        String id = txtId.getText().trim();
        String name = txtName.getText().trim();
        String salary = txtSalary.getText().trim();

        if (id.isEmpty() || name.isEmpty() || salary.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields");
            return;
        }

        try {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE employees SET emp_name = ?, salary = ? WHERE emp_id = ?");
            ps.setString(1, name);
            ps.setString(2, salary);
            ps.setString(3, id);
            int updated = ps.executeUpdate();
            ps.close();

            if (updated > 0) {
                JOptionPane.showMessageDialog(this, "Employee updated.");
                clearFields();
                loadEmployees();
            } else {
                JOptionPane.showMessageDialog(this, "Employee ID not found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error updating employee: " + ex.getMessage());
        }
    }

    private void deleteEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an employee row to delete.");
            return;
        }
        String empId = (String) tableModel.getValueAt(selectedRow, 1);

        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM employees WHERE emp_id = ?");
            ps.setString(1, empId);
            ps.executeUpdate();
            ps.close();
            JOptionPane.showMessageDialog(this, "Selected employee deleted.");
            clearFields();
            loadEmployees();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting employee: " + ex.getMessage());
        }
    }

    private void loadEmployees() {
        tableModel.setRowCount(0);
        int serial = 1;

        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM employees");
            while (rs.next()) {
                Object[] row = new Object[]{
                    serial++,
                    rs.getString("emp_id"),
                    rs.getString("emp_name"),
                    rs.getString("salary")
                };
                tableModel.addRow(row);
            }
            rs.close();
            stmt.close();
            clearFields();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading employees: " + ex.getMessage());
        }
    }

    private void searchEmployee() {
        String keyword = txtSearch.getText().trim();

        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter ID or Name to search");
            return;
        }

        tableModel.setRowCount(0);
        int serial = 1;

        try {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM employees WHERE emp_id LIKE ? OR emp_name LIKE ?");
            String queryParam = "%" + keyword + "%";
            ps.setString(1, queryParam);
            ps.setString(2, queryParam);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] row = new Object[]{
                    serial++,
                    rs.getString("emp_id"),
                    rs.getString("emp_name"),
                    rs.getString("salary")
                };
                tableModel.addRow(row);
            }
            rs.close();
            ps.close();

            if (serial == 1) {
                JOptionPane.showMessageDialog(this, "No matching employees found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching employees: " + ex.getMessage());
        }
    }

    private void clearFields() {
        txtId.setText("");
        txtName.setText("");
        txtSalary.setText("");
        txtSearch.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EmployeeCRUD().setVisible(true));
    }
}
