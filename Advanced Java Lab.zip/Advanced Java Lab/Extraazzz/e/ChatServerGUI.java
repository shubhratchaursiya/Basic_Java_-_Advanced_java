package e;
import javax.swing.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServerGUI extends JFrame {
    JTextArea area;
    List<ClientHandler> clients = Collections.synchronizedList(new ArrayList<>());

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ChatServerGUI());
    }

    ChatServerGUI() {
        setTitle("Server Side Chat Application");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        area = new JTextArea();
        area.setEditable(false);
        add(new JScrollPane(area));
        setVisible(true);

        // Start server thread
        new Thread(this::startServer).start();
    }

    void startServer() {
        try (ServerSocket ss = new ServerSocket(5000)) {
            area.append("Server started on port 5000\n");
            while (true) {
                Socket s = ss.accept();
                ClientHandler ch = new ClientHandler(s, this);
                clients.add(ch);
                new Thread(ch).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void broadcast(String msg) {
        area.append(msg + "\n");
        synchronized (clients) {
            for (ClientHandler c : clients) c.send(msg);
        }
    }

    static class ClientHandler implements Runnable {
        Socket socket;
        PrintWriter out;
        BufferedReader in;
        ChatServerGUI server;
        String name;

        ClientHandler(Socket s, ChatServerGUI server) {
            this.socket = s;
            this.server = server;
            try {
                out = new PrintWriter(s.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(s.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                // First line from client is the client's name
                name = in.readLine();
                if (name == null) return;
                server.broadcast(name + " joined");
                String msg;
                while ((msg = in.readLine()) != null) {
                    server.broadcast(name + ": " + msg);
                }
            } catch (IOException e) {
                // ignore
            } finally {
                server.clients.remove(this);
                server.broadcast((name != null ? name : "A client") + " left");
                try { socket.close(); } catch (IOException ignored) {}
            }
        }

        void send(String m) {
            out.println(m);
        }
    }
}
