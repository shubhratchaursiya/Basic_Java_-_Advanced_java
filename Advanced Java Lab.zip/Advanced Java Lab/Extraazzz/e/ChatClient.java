package e;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ChatClient extends JFrame {
    private JTextArea area;
    private JTextField field;
    private PrintWriter out;
    private BufferedReader in;

    public ChatClient() {
        setTitle("Client Side Chat Application");
        setSize(500, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel header = new JLabel("Multiple Client Requests by SHUBHRAT CHAURSIYA : 23EARIT053", SwingConstants.CENTER);
        header.setFont(new Font("Serif", Font.BOLD, 16));
        add(header, BorderLayout.NORTH);

        area = new JTextArea();
        area.setEditable(false);
        add(new JScrollPane(area), BorderLayout.CENTER);

        field = new JTextField();
        field.setEnabled(false); // enable after successful connect
        add(field, BorderLayout.SOUTH);

        field.addActionListener(e -> {
            String msg = field.getText().trim();
            if (!msg.isEmpty()) {
                out.println(msg);
                field.setText("");
            }
        });

        setVisible(true);
        connectToServer();
    }

    private void connectToServer() {
        try {
            Socket s = new Socket("localhost", 5000);
            out = new PrintWriter(s.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(s.getInputStream()));

            // Ask user for name and send it as the first line
            String name = JOptionPane.showInputDialog(this, "Enter your name:");
            if (name == null || name.trim().isEmpty()) {
                s.close();
                dispose();
                return;
            }
            out.println(name.trim());
            field.setEnabled(true);

            // Reader thread
            new Thread(() -> {
                try {
                    String msg;
                    while ((msg = in.readLine()) != null) {
                        area.append(msg + "\n");
                    }
                } catch (IOException e) {
                    area.append("Connection lost.\n");
                }
            }).start();

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Unable to connect to server (is it running?)", "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChatClient::new);
    }
}
