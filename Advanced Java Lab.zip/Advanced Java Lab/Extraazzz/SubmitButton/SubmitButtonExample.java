package External;

import javax.swing.*;
import java.awt.event.*;

public class SubmitButtonExample {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Button ActionListener Example");
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JButton SubmitBtn = new JButton("Submit");
        SubmitBtn.setBounds(80, 60, 120, 30);

        SubmitBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(frame, "Submit button clicked!");
            }
        });

        frame.add(SubmitBtn);

        frame.setVisible(true);
    }
}
