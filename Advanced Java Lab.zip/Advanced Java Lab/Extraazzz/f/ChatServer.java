package f;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

public class ChatServer extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private PrintWriter out;

    public ChatServer() {
        setTitle("Server Side Chat Application");
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ---- Chat Area ----
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setBackground(new Color(230, 250, 250));
        chatArea.setFont(new Font("Arial", Font.PLAIN, 14));

        // ---- JScrollPane (Line 56) ----
        JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
        add(scrollPane, BorderLayout.CENTER);

        // ---- Input Panel ----
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(200, 220, 240)); 
        inputField = new JTextField();
        inputField.setFont(new Font("Arial", Font.PLAIN, 14));

        sendButton = new JButton("Send");
        sendButton.setBackground(new Color(100, 180, 255));
        sendButton.setForeground(Color.white);
        sendButton.setFont(new Font("Arial", Font.BOLD, 14));

        panel.add(inputField, BorderLayout.CENTER);
        panel.add(sendButton, BorderLayout.EAST);
        add(panel, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        getContentPane().setBackground(new Color(180, 200, 220)); // frame background
        setVisible(true);

        new Thread(this::startServer).start();
    }

    private void startServer() {
        try (ServerSocket serverSocket = new ServerSocket(1234)) {
            appendMessage("Server started. Waiting for client...\n");

            Socket socket = serverSocket.accept();
            appendMessage("shambhavi connected!\n");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String msg;
            while ((msg = in.readLine()) != null) {
                appendMessage("shambhavi: " + msg + "\n");
            }
        } catch (Exception e) {
            appendMessage("Error: " + e.getMessage() + "\n");
        }
    }

    private void sendMessage() {
        String msg = inputField.getText();
        if (!msg.isEmpty()) {
            appendMessage("Kush: " + msg + "\n");
            out.println(msg);
            inputField.setText("");
        }
    }

    private void appendMessage(String msg) {
        SwingUtilities.invokeLater(() -> chatArea.append(msg));
    }

    public static void main(String[] args) {
        new ChatServer();
    }
}
