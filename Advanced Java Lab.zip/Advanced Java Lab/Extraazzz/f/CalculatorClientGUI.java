package f;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CalculatorClientGUI {
    private JFrame frame;
    private JTextField aField;
    private JTextField bField;
    private JComboBox<String> opBox;
    private JButton calcButton;
    private JButton clearButton;
    private Calculator remote;

    public CalculatorClientGUI() {
        lookupRemote();
        initUI();
    }

    private void lookupRemote() {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            remote = (Calculator) registry.lookup(CalculatorServer.BIND_NAME);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed to connect to RMI server: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }

    private void initUI() {
        frame = new JFrame("RMI Calculator");
        frame.setSize(600, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.GREEN);
        frame.setLocationRelativeTo(null);

        // Heading
        JLabel heading = new JLabel("RMI Calculator by SHUBHRAT CHAURSIYA - 23EARIT053", SwingConstants.CENTER);
        heading.setBounds(50, 10, 500, 30);
        heading.setFont(new Font("Serif", Font.BOLD, 18));
        heading.setForeground(Color.RED);
        frame.add(heading);

        // Input fields and labels
        JLabel labelA = new JLabel("Number 1:");
        labelA.setBounds(80, 70, 100, 25);
        frame.add(labelA);

        aField = new JTextField();
        aField.setBounds(160, 70, 120, 25);
        frame.add(aField);

        JLabel labelB = new JLabel("Number 2:");
        labelB.setBounds(300, 70, 100, 25);
        frame.add(labelB);

        bField = new JTextField();
        bField.setBounds(380, 70, 120, 25);
        frame.add(bField);

        // Operation ComboBox
        String[] ops = {"add", "subtract", "multiply", "divide", "power", "modulo"};
        opBox = new JComboBox<>(ops);
        opBox.setBounds(230, 110, 150, 25);
        frame.add(opBox);

        // Calculate button
        calcButton = new JButton("Calculate");
        calcButton.setBounds(160, 160, 120, 30);
        calcButton.addActionListener(this::onCalculate);
        frame.add(calcButton);

        // Clear button
        clearButton = new JButton("Clear");
        clearButton.setBounds(320, 160, 120, 30);
        clearButton.addActionListener(ev -> {
            aField.setText("");
            bField.setText("");
        });
        frame.add(clearButton);

        frame.setVisible(true);
    }

    private void onCalculate(ActionEvent e) {
        double a, b;
        try {
            a = Double.parseDouble(aField.getText().trim());
            b = Double.parseDouble(bField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Enter valid numbers for A and B", "Input error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String op = (String) opBox.getSelectedItem();
        double result;

        try {
            switch (op) {
                case "add": result = remote.add(a, b); break;
                case "subtract": result = remote.subtract(a, b); break;
                case "multiply": result = remote.multiply(a, b); break;
                case "divide": result = remote.divide(a, b); break;
                case "power": result = remote.power(a, b); break;
                case "modulo": result = remote.modulo(a, b); break;
                default: throw new IllegalStateException("Unknown op");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Remote error: " + ex.getMessage(), "RMI error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        openResultWindow(a, b, op, result);
    }

    private void openResultWindow(double a, double b, String op, double result) {
        JFrame resultFrame = new JFrame("Result - By SHUBHRAT CHAURSIYA");
        resultFrame.setSize(550, 250);
        resultFrame.setLocationRelativeTo(frame);
        resultFrame.setLayout(null);
        resultFrame.getContentPane().setBackground(Color.GREEN);
        resultFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel heading = new JLabel("RMI Calculator", SwingConstants.CENTER);
        heading.setBounds(50, 10, 450, 30);
        heading.setFont(new Font("Serif", Font.BOLD, 16));
        heading.setForeground(Color.RED);
        resultFrame.add(heading);

        String opSymbol = getSymbol(op);
        JLabel label = new JLabel(String.format("%s %s %s = %s", trimZeros(a), opSymbol, trimZeros(b), trimZeros(result)), SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.BOLD, 22));
        label.setBounds(50, 70, 450, 40);
        label.setForeground(Color.BLACK);
        resultFrame.add(label);

        JButton close = new JButton("Close");
        close.setBounds(200, 140, 120, 30);
        close.addActionListener(ev -> resultFrame.dispose());
        resultFrame.add(close);

        resultFrame.setVisible(true);
    }

    private String getSymbol(String op) {
        switch (op) {
            case "add": return "+";
            case "subtract": return "-";
            case "multiply": return "×";
            case "divide": return "÷";
            case "power": return "^";
            case "modulo": return "%";
            default: return "?";
        }
    }

    private String trimZeros(double v) {
        if (v == (long) v) return String.format("%d", (long) v);
        return String.format("%.6f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CalculatorClientGUI::new);
    }
}
