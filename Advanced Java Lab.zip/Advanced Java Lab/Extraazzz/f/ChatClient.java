package f;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
public class ChatClient extends JFrame {
    private JTextArea chatArea;
    private JTextField inputField;
    private JButton sendButton;
    private PrintWriter out;
    public ChatClient() {
        setTitle("Client Side Chat Application");
         
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        chatArea = new JTextArea();
        chatArea.setEditable(false);
        chatArea.setBackground(new Color(245, 200, 255));
        chatArea.setFont(new Font("Arial", Font.PLAIN, 14));
         JScrollPane scrollPane = new JScrollPane(chatArea);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
        add(scrollPane, BorderLayout.CENTER); 
        		JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.yellow); 

        inputField = new JTextField();
        inputField.setFont(new Font("Arial", Font.PLAIN, 14));

        sendButton = new JButton("Send");
        sendButton.setBackground(Color.gray);
        sendButton.setForeground(Color.white);
        sendButton.setFont(new Font("Arial", Font.BOLD, 14));

        panel.add(inputField, BorderLayout.CENTER);
        panel.add(sendButton, BorderLayout.EAST);
        add(panel, BorderLayout.SOUTH);

        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());

        getContentPane().setBackground(new Color(200, 180, 220)); // frame background
        setVisible(true);

        new Thread(this::connectToServer).start();
    }

    private void connectToServer() {
        try (Socket socket = new Socket("localhost", 1234)) {
            appendMessage("Connected to server...\n");

            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String msg;
            while ((msg = in.readLine()) != null) {
                appendMessage("Kush: " + msg + "\n");
            }
        } catch (Exception e) {
            appendMessage("Error: " + e.getMessage() + "\n");
        }
    }

    private void sendMessage() {
        String msg = inputField.getText();
        if (!msg.isEmpty()) {
            appendMessage("shambhavi: " + msg + "\n");
            out.println(msg);
            inputField.setText("");
        }
    }

    private void appendMessage(String msg) {
        SwingUtilities.invokeLater(() -> chatArea.append(msg));
    }

    public static void main(String[] args) {
        new ChatClient();
    }
}