package f;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class CalculatorServer {
    public static final String BIND_NAME = "CalculatorService";

    public static void main(String[] args) {
        try {
            // Create (or get) RMI registry on port 1099
            Registry registry = LocateRegistry.createRegistry(1099);

            // Create implementation and bind it
            CalculatorImpl impl = new CalculatorImpl();
            registry.rebind(BIND_NAME, impl);

            System.out.println("CalculatorService bound. RMI server ready on port 1099.");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
