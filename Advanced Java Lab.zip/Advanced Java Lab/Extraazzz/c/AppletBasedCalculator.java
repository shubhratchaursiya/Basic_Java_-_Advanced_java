package c;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AppletBasedCalculator extends JFrame implements ActionListener {
    JTextField t1, t2, result;
    JButton add, sub, mul, div;

    public AppletBasedCalculator() {
        setTitle("Basic Calculator by Shubhrat Chaursiya : 23EARIT053");
        setSize(400, 250);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 2, 10, 10));

        JLabel l1 = new JLabel("Enter First Number:");
        t1 = new JTextField();
        JLabel l2 = new JLabel("Enter Second Number:");
        t2 = new JTextField();
        JLabel l3 = new JLabel("Result:");
        result = new JTextField();
        result.setEditable(false);

        add = new JButton("Add");
        sub = new JButton("Subtract");
        mul = new JButton("Multiply");
        div = new JButton("Divide");

        add(l1); add(t1);
        add(l2); add(t2);
        add(l3); add(result);
        add(add); add(sub);
        add(mul); add(div);

        add.addActionListener(this);
        sub.addActionListener(this);
        mul.addActionListener(this);
        div.addActionListener(this);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            double num1 = Double.parseDouble(t1.getText());
            double num2 = Double.parseDouble(t2.getText());
            double res = 0;

            if (e.getSource() == add) {
                res = num1 + num2;
            } else if (e.getSource() == sub) {
                res = num1 - num2;
            } else if (e.getSource() == mul) {
                res = num1 * num2;
            } else if (e.getSource() == div) {
                if (num2 != 0) {
                    res = num1 / num2;
                } else {
                    JOptionPane.showMessageDialog(this, "Cannot divide by zero!");
                    return;
                }
            }
            result.setText(String.valueOf(res));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers!");
        }
    }

    public static void main(String[] args) {
        new AppletBasedCalculator();
    }
}