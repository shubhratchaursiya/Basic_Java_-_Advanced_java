package g;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ArithmeticClient extends JFrame {
    private JTextField num1Field, num2Field, resultField;
    private Arithmetic stub;

    public ArithmeticClient() {
        setTitle("RMI Arithmetic Client");
        setSize(500, 350);
        setLayout(new BorderLayout(10, 10));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Title Label (Your Name / Info)
        JLabel titleLabel = new JLabel("Arithmetic Operations using RMI By shambhavi- 23EARIT050", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        titleLabel.setForeground(Color.BLUE);
        add(titleLabel, BorderLayout.NORTH);

        // Panel for Inputs & Buttons
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));

        JLabel l1 = new JLabel("Enter First Number:");
        num1Field = new JTextField();
        JLabel l2 = new JLabel("Enter Second Number:");
        num2Field = new JTextField();
        JLabel l3 = new JLabel("Result:");
        resultField = new JTextField();
        resultField.setEditable(false);

        JButton addBtn = new JButton("Add");
        JButton subBtn = new JButton("Subtract");
        JButton mulBtn = new JButton("Multiply");
        JButton divBtn = new JButton("Divide");

        panel.add(l1); panel.add(num1Field);
        panel.add(l2); panel.add(num2Field);
        panel.add(l3); panel.add(resultField);
        panel.add(addBtn); panel.add(subBtn);
        panel.add(mulBtn); panel.add(divBtn);

        add(panel, BorderLayout.CENTER);

        // Connect to RMI Server
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            stub = (Arithmetic) registry.lookup("ArithmeticService");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error connecting to server: " + e.getMessage());
        }

        // Action Listeners
        addBtn.addActionListener((ActionEvent e) -> performOperation("add"));
        subBtn.addActionListener((ActionEvent e) -> performOperation("subtract"));
        mulBtn.addActionListener((ActionEvent e) -> performOperation("multiply"));
        divBtn.addActionListener((ActionEvent e) -> performOperation("divide"));
    }

    private void performOperation(String op) {
        try {
            double a = Double.parseDouble(num1Field.getText());
            double b = Double.parseDouble(num2Field.getText());
            double res = 0;

            switch (op) {
                case "add": res = stub.add(a, b); break;
                case "subtract": res = stub.subtract(a, b); break;
                case "multiply": res = stub.multiply(a, b); break;
                case "divide": res = stub.divide(a, b); break;
            }

            resultField.setText(String.valueOf(res));
            JOptionPane.showMessageDialog(this, "Result: " + res); // popup
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ArithmeticClient().setVisible(true));
    }
}
