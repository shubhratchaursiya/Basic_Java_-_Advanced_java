package g;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

class Student implements Serializable {
    private String name;
    private String rollNo;
    private String branch;

    public Student(String name, String rollNo, String branch) {
        this.name = name;
        this.rollNo = rollNo;
        this.branch = branch;
    }

    public String getName() { return name; }
    public String getRollNo() { return rollNo; }
    public String getBranch() { return branch; }

    public void setName(String name) { this.name = name; }
    public void setBranch(String branch) { this.branch = branch; }

    @Override
    public String toString() {
        return "Name: " + name + " | Roll No: " + rollNo + " | Branch: " + branch;
    }
}

public class StudentDataApp {
    private JFrame frame;
    private JTextField nameField;
    private JTextField rollField;
    private JTextField branchField;
    private JButton saveButton, updateButton, clearButton, showAllButton, deleteButton;

    private final String FILE_NAME = "students.dat";

    // Reusable case-insensitive comparator by name
    private static final Comparator<Student> BY_NAME_CI =
            Comparator.comparing(Student::getName, String.CASE_INSENSITIVE_ORDER); // case-insensitive comparator [9][3][4]

    public StudentDataApp() { initUI(); }

    private void initUI() {
        frame = new JFrame("Student Data");
        frame.setSize(760, 420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.GREEN);
        frame.setLocationRelativeTo(null);

        JLabel heading = new JLabel("Student Data Serializer By - SHUBHRAT CHAURSIYA 23EARIT053", SwingConstants.CENTER);
        heading.setBounds(20, 10, 700, 30);
        heading.setFont(new Font("Serif", Font.BOLD, 16));
        heading.setForeground(Color.RED);
        frame.add(heading);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(100, 70, 100, 25);
        frame.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(200, 70, 420, 25);
        frame.add(nameField);

        JLabel rollLabel = new JLabel("Roll No:");
        rollLabel.setBounds(100, 110, 100, 25);
        frame.add(rollLabel);

        rollField = new JTextField();
        rollField.setBounds(200, 110, 420, 25);
        frame.add(rollField);

        JLabel branchLabel = new JLabel("Branch:");
        branchLabel.setBounds(100, 150, 100, 25);
        frame.add(branchLabel);

        branchField = new JTextField();
        branchField.setBounds(200, 150, 420, 25);
        frame.add(branchField);

        saveButton = new JButton("Save Student");
        saveButton.setBounds(40, 220, 150, 30);
        saveButton.addActionListener(this::onSave);
        frame.add(saveButton);

        updateButton = new JButton("Update Student");
        updateButton.setBounds(200, 220, 160, 30);
        updateButton.addActionListener(this::onUpdate);
        frame.add(updateButton);

        deleteButton = new JButton("Delete Student");
        deleteButton.setBounds(370, 220, 150, 30);
        deleteButton.addActionListener(this::onDelete);
        frame.add(deleteButton);

        showAllButton = new JButton("Show Full Data");
        showAllButton.setBounds(530, 220, 150, 30);
        showAllButton.addActionListener(this::onShowAll);
        frame.add(showAllButton);

        clearButton = new JButton("Clear");
        clearButton.setBounds(320, 270, 100, 30);
        clearButton.addActionListener(ev -> clearFields());
        frame.add(clearButton);

        frame.setVisible(true);
    }

    private void clearFields() {
        nameField.setText("");
        rollField.setText("");
        branchField.setText("");
    }

    private void onSave(ActionEvent e) {
        String name = nameField.getText().trim();
        String roll = rollField.getText().trim();
        String branch = branchField.getText().trim();

        if (name.isEmpty() || roll.isEmpty() || branch.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill all fields", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<Student> students = readStudents();
        students.add(new Student(name, roll, branch));
        students.sort(BY_NAME_CI); // keep file sorted after insert [2][6][9]
        writeStudents(students);

        JOptionPane.showMessageDialog(frame, "Student saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        clearFields();
    }

    private void onUpdate(ActionEvent e) {
        String name = nameField.getText().trim();
        String roll = rollField.getText().trim();
        String branch = branchField.getText().trim();

        if (roll.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Enter Roll No to update student!", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        List<Student> students = readStudents();
        boolean found = false;
        for (Student s : students) {
            if (s.getRollNo().equalsIgnoreCase(roll)) {
                if (!name.isEmpty()) s.setName(name);
                if (!branch.isEmpty()) s.setBranch(branch);
                found = true;
                break;
            }
        }

        if (found) {
            students.sort(BY_NAME_CI); // re-sort after update [2][15][9]
            writeStudents(students);
            JOptionPane.showMessageDialog(frame, "Student updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
        } else {
            JOptionPane.showMessageDialog(frame, "Student with Roll No " + roll + " not found!", "Update Failed", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onDelete(ActionEvent e) {
        String roll = rollField.getText().trim();
        if (roll.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Enter Roll No to delete student!", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int choice = JOptionPane.showConfirmDialog(
                frame,
                "Are you sure you want to delete student with Roll No: " + roll + "?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        ); // confirm dialog pattern [21][22][23]
        if (choice != JOptionPane.YES_OPTION) return;

        List<Student> students = readStudents();
        boolean removed = students.removeIf(s -> s.getRollNo().equalsIgnoreCase(roll));
        if (removed) {
            students.sort(BY_NAME_CI); // re-sort after delete (keeps invariant) [2][6][9]
            writeStudents(students);
            JOptionPane.showMessageDialog(frame, "Student deleted successfully!", "Deleted", JOptionPane.INFORMATION_MESSAGE);
            clearFields();
        } else {
            JOptionPane.showMessageDialog(frame, "Student with Roll No " + roll + " not found!", "Delete Failed", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onShowAll(ActionEvent e) {
        List<Student> students = readStudents();
        if (students.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No student data found.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        students.sort(BY_NAME_CI); // ensure sorted before display [1][4][19]

        StringBuilder sb = new StringBuilder("All Students:\n\n");
        for (int i = 0; i < students.size(); i++) {
            sb.append((i + 1)).append(". ").append(students.get(i).toString()).append("\n");
        }

        JOptionPane.showMessageDialog(frame, sb.toString(), "Full Student Data", JOptionPane.INFORMATION_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    private List<Student> readStudents() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            // Deserialize list; order as stored will be preserved; we re-sort to enforce alpha order. [7][18][16]
            return (List<Student>) ois.readObject();
        } catch (Exception ex) {
            return new ArrayList<>();
        }
    }

    private void writeStudents(List<Student> students) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(students);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "Error writing students: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentDataApp::new);
    }
}
