package d;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
public class StudentRegistration extends JFrame {
    private static final long serialVersionUID = 1L;
    JTextField txtId, txtName, txtMobile;
    JTable table;
    DefaultTableModel model;

    Connection conn;
    PreparedStatement pst;
    ResultSet rs;

    public StudentRegistration() {
        setTitle("Student Registration Desk");
        setSize(750, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.PINK);
        setLayout(null);

        JLabel lblTitle = new JLabel("Student Registration Portal By Shubhrat Chaursiya 23EARIT053", JLabel.CENTER);
        lblTitle.setBounds(50, 10, 650, 30);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        add(lblTitle);

        JLabel lblId = new JLabel("Student Id");
        lblId.setBounds(30, 60, 100, 25);
        add(lblId);

        txtId = new JTextField();
        txtId.setBounds(150, 60, 150, 25);
        add(txtId);

        JLabel lblName = new JLabel("Student Name");
        lblName.setBounds(30, 100, 100, 25);
        add(lblName);

        txtName = new JTextField();
        txtName.setBounds(150, 100, 150, 25);
        add(txtName);

        JLabel lblMobile = new JLabel("Mobile No.");
        lblMobile.setBounds(30, 140, 100, 25);
        add(lblMobile);

        txtMobile = new JTextField();
        txtMobile.setBounds(150, 140, 150, 25);
        add(txtMobile);

        JButton btnSave = new JButton("Save");
        btnSave.setBounds(30, 200, 80, 30);
        add(btnSave);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(120, 200, 80, 30);
        add(btnSearch);

        JButton btnUpdate = new JButton("Update");
        btnUpdate.setBounds(210, 200, 80, 30);
        add(btnUpdate);

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBounds(300, 200, 80, 30);
        add(btnDelete);

        JButton btnLoad = new JButton("Load");
        btnLoad.setBounds(390, 200, 80, 30);
        add(btnLoad);

        model = new DefaultTableModel(new String[]{"S.No", "stuid", "stuname", "stumobile"}, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(350, 60, 360, 120);
        add(sp);

        connect();

        btnSave.addActionListener(e -> saveStudent());
        btnSearch.addActionListener(e -> searchStudent());
        btnUpdate.addActionListener(e -> updateStudent());
        btnDelete.addActionListener(e -> deleteStudent());
        btnLoad.addActionListener(e -> loadStudents());
    }

    private void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/?useSSL=false&serverTimezone=UTC";
            String username = "root";
            String password = "Kushaditi@0829";
            conn = DriverManager.getConnection(url, username, password);
            Statement stmt = conn.createStatement();
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS studentdb");
            stmt.close();
            conn.close();
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb?useSSL=false&serverTimezone=UTC", username, password);
            System.out.println("✅ Connected to Database");
            stmt = conn.createStatement();
            stmt.execute("CREATE TABLE IF NOT EXISTS students (" +
                         "stuid INT PRIMARY KEY, " +
                         "stuname VARCHAR(100), " +
                         "stumobile VARCHAR(15))");
            stmt.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to database: " + e.getMessage());
            System.exit(1);
        }
    }

    void saveStudent() {
        try {
            String sql = "INSERT INTO students(stuid, stuname, stumobile) VALUES(?, ?, ?)";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(txtId.getText()));
            pst.setString(2, txtName.getText());
            pst.setString(3, txtMobile.getText());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "✅ Student Saved!");
            clearFields();
            loadStudents();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error Saving: " + e.getMessage());
        }
    }

    void searchStudent() {
        try {
            String sql = "SELECT * FROM students WHERE stuid=?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(txtId.getText()));
            rs = pst.executeQuery();
            if (rs.next()) {
                txtName.setText(rs.getString("stuname"));
                txtMobile.setText(rs.getString("stumobile"));
            } else {
                JOptionPane.showMessageDialog(this, "❌ Student Not Found!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error Searching: " + e.getMessage());
        }
    }

    void updateStudent() {
        try {
            String sql = "UPDATE students SET stuname=?, stumobile=? WHERE stuid=?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtName.getText());
            pst.setString(2, txtMobile.getText());
            pst.setInt(3, Integer.parseInt(txtId.getText()));
            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "✅ Student Updated!");
                clearFields();
                loadStudents();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Student Not Found!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error Updating: " + e.getMessage());
        }
    }

    void deleteStudent() {
        try {
            String sql = "DELETE FROM students WHERE stuid=?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1, Integer.parseInt(txtId.getText()));
            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "🗑️ Student Deleted!");
                clearFields();
                loadStudents();
            } else {
                JOptionPane.showMessageDialog(this, "❌ Student Not Found!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error Deleting: " + e.getMessage());
        }
    }

    void loadStudents() {
        try {
            model.setRowCount(0);
            String sql = "SELECT * FROM students";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            int sno = 1;
            while (rs.next()) {
                model.addRow(new Object[]{
                        sno++, 
                        rs.getInt("stuid"), 
                        rs.getString("stuname"), 
                        rs.getString("stumobile")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error Loading: " + e.getMessage());
        }
    }

    void clearFields() {
        txtId.setText("");
        txtName.setText("");
        txtMobile.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new StudentRegistration().setVisible(true));
    }
}
