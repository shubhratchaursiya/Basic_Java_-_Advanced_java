/* Login System Using TextFields and Button With MVC Pattern. Basic Swing Controls To Be Used.*/
package a;

 import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GUILoginForm {
    public static void main(String[] args) {
    	
        JFrame frame = new JFrame("Login System");
        frame.setSize(400, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.getContentPane().setBackground(Color.PINK);

        JLabel headingLabel = new JLabel("Login By SHUBHRAT CHAURSIYA : 23EARIT053 ");
        headingLabel.setBounds(60, 20, 300, 25);
        headingLabel.setForeground(Color.yellow);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 70, 100, 25);
        userLabel.setForeground(Color.WHITE);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 110, 100, 25);
        passLabel.setForeground(Color.WHITE);

        JTextField userField = new JTextField();
        userField.setBounds(150, 70, 180, 25);

        JPasswordField passField = new JPasswordField();
        passField.setBounds(150, 110, 180, 25);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(150, 160, 100, 30);

        // Simple model (credentials)
        String validUser = "Shubhrat@0829";
        String validPass = "Arya@23-27";

        // Controller: Handle Login Action
        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = userField.getText();
                String password = new String(passField.getPassword());

                if (username.equals(validUser) && password.equals(validPass)) {
                    JOptionPane.showMessageDialog(frame, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid Credentials!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        frame.add(headingLabel);
        frame.add(userLabel);
        frame.add(passLabel);
        frame.add(userField);
        frame.add(passField);
        frame.add(loginBtn);

        frame.setVisible(true);
    }
}