package a;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class StudentRegistrationPage {

	public static void main(String[] args) {
		JFrame f=new JFrame("Student Registration by Shubhrat Chaursiya");
		f.setSize(400, 400);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLayout(null);
		f.getContentPane().setBackground(Color.RED);
		
		JLabel lLabel = new JLabel("This is by SHUBHRAT CHAURSIYA 23EARIT053");
		lLabel.setBounds(20, 20, 300, 25);
		
		
		 JLabel nameLabel = new JLabel("Name:");
	        nameLabel.setBounds(20, 70, 80, 25);
	        
	     JLabel fathernameLabel = new JLabel("Father Name:");
	        fathernameLabel.setBounds(20, 100, 80, 25);

	     JLabel rollLabel = new JLabel("Roll No:");
	        rollLabel.setBounds(20, 140, 80, 25);

	     JLabel courseLabel = new JLabel("Course:");
	        courseLabel.setBounds(20, 180, 80, 25);
	        
	     JLabel yearLabel = new JLabel("year:");
	        yearLabel.setBounds(20, 210, 80, 25); 
	        
	        
	     JTextField nameField=new JTextField();
	     nameField.setBounds(100, 70, 200, 25);
	     
	     JTextField fathernameField=new JTextField();
	     fathernameField.setBounds(100, 100, 200, 25);
	     
	     JTextField rollField=new JTextField();
	     rollField.setBounds(100, 140, 200, 25);
	     
	     JTextField courseField=new JTextField();
	     courseField.setBounds(100, 180, 200, 25);
	     
	     JTextField yearField=new JTextField();
	     yearField.setBounds(100, 210, 200, 25);
	     
	     JButton submitButton = new JButton("Submit");
	        submitButton.setBounds(100, 300, 100, 30);
		
		f.add(nameLabel);
		f.add(fathernameLabel);
		f.add(rollLabel);
		f.add(courseLabel);
		f.add(yearLabel);
		f.add(lLabel);
		
		
		f.add(nameField);
		f.add(fathernameField);
		f.add(rollField);
		f.add(courseField);
		f.add(yearField);
		f.add(submitButton);
		
		submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String fathername = fathernameField.getText();
                String roll = rollField.getText();
                String course = courseField.getText();
                String year = yearField.getText();

                JOptionPane.showMessageDialog(f,
                        "Student Details:\nName: " + name + 
                        "\nfathername: " + fathername +
                        "\nRoll No: " + roll +
                        "\nCourse: " + course +
                        "\nyear:" + year,
                        "Student Information",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
		
		f.setVisible(true);
	}

}