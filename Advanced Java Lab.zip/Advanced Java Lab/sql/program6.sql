create database logintable;
use logintable;
create table userdata (u_name varchar (255) , u_pass int );
insert into userdata values ("name" , pass);
select * from userdata;
