create database logindatabases;
use logindatabases;
CREATE TABLE employee (
    series_number INT AUTO_INCREMENT PRIMARY KEY,  
    name VARCHAR(100) ,
    id VARCHAR(50) ,  
    mobile_number VARCHAR(15)  
);